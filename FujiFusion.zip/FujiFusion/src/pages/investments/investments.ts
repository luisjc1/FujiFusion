import {Component, OnInit} from '@angular/core';
import {NavController} from 'ionic-angular';

import {InvestmentPage} from "../investment/investment";

import * as investmentCompanies from "../../data/investment_companies.json";

import { AngularFireDatabase } from 'angularfire2/database';
import {InfoPage} from "../info/info";

@Component({
  selector: 'page-investments',
  templateUrl: 'investments.html'
})
export class InvestmentsPage implements OnInit {
  investmentCompanies: any;
  investments: any;

  constructor(public navCtrl: NavController, private fdb: AngularFireDatabase) {
    console.log(this.fdb.list('/investments').query);

    this.investmentCompanies = investmentCompanies;
  }

  ngOnInit() {
    this.investments = this.manageInvestments();

  }

  itemTapped(event, investment) {
    this.navCtrl.push(InvestmentPage, {
      investment: investment
    });
  }

  infoTapped(event, investment) {
    this.navCtrl.push(InfoPage, {
      investment: investment
    });
  }

  onInput(ev: any) {
    // Reset Items
    this.investments = this.manageInvestments();
    // Set Value
    const val = ev.target.value;
    // Check Value and Search
    if (val && val.trim() != '') {
      this.investments = this.investments.filter(investment => {
        return ((investment.companyName + " " + investment.ticker).toLowerCase().indexOf(val.toLowerCase()) > -1);
      })
    }
  }

  manageInvestments() {
    const investments = this.filterInvestments();
    return this.sortInvestments(investments);
  }

  filterInvestments() {
    return this.investmentCompanies.filter(investment => investment.value > 0);
  }

  sortInvestments(investments) {
    return investments.sort((a, b) => a.value > b.value ? -1 : a.value === b.value ? 0 : 1);
  }
}
