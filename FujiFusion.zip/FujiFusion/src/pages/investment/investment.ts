import {Component, OnInit} from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import { AngularFireDatabase } from 'angularfire2/database';

@Component({
  selector: 'page-investment',
  templateUrl: 'investment.html'
})
export class InvestmentPage implements OnInit {
  investment: InvestmentPage;
  selectedShares: number;
  firebaseData: any[];

  constructor(public navCtrl: NavController, public navParams: NavParams, private fdb: AngularFireDatabase) {
    this.investment = navParams.get('investment');
  }

  ngOnInit() {
    this.selectedShares = 0;
  }

  incrementShare() {
    this.selectedShares ++;
  }

  decrementShare() {
    this.selectedShares --;
  }

  onClickBuy() {
    this.fdb.list("investments").push(this.investment);

  }

  onClickSell() {
    this.fdb.list("investments").push(this.investment);
  }
}
