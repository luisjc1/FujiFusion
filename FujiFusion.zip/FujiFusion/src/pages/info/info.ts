import {Component} from '@angular/core';
import {NavController, NavParams} from 'ionic-angular';
import {InvestmentModel} from "../../models/investmentModel";

@Component({
  selector: 'page-info',
  templateUrl: 'info.html'
})
export class InfoPage {
  investment: InvestmentModel;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.investment = navParams.get('investment');
  }
}
