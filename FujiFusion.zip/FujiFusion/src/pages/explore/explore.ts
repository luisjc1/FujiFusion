import {Component, OnInit} from '@angular/core';
import {NavController} from 'ionic-angular';

import {InvestmentPage} from "../investment/investment";

import * as investmentCompanies from "../../data/investment_companies.json";

@Component({
  selector: 'page-explore',
  templateUrl: 'explore.html'
})
export class ExplorePage implements OnInit {
  investmentCompanies: any;
  uninvestedCompanies: any;

  constructor(public navCtrl: NavController) {

    this.investmentCompanies = investmentCompanies;

  }

  ngOnInit() {
    this.uninvestedCompanies = this.manageUninvestedCompanies();

  }

  itemTapped(event, company) {
    this.navCtrl.push(InvestmentPage, {
      investment: company
    });
  }

  onInput(ev: any) {
    // Reset Items
    this.uninvestedCompanies = this.manageUninvestedCompanies();
    // Set Value
    const val = ev.target.value;
    // Check Value and Search
    if (val && val.trim() != '') {
      this.uninvestedCompanies = this.uninvestedCompanies.filter(company => {
        return ((company.companyName + " " + company.ticker).toLowerCase().indexOf(val.toLowerCase()) > -1);
      })
    }
  }

  manageUninvestedCompanies() {
    const uninvestedCompanies = this.filterUninvestedCompanies();
    return this.sortUninvestedCompanies(uninvestedCompanies);
  }

  filterUninvestedCompanies() {
    return this.investmentCompanies.filter(company => company.value == 0);
  }

  sortUninvestedCompanies(uninvestedCompanies) {
    return uninvestedCompanies.sort((a, b) => a.delta < b.delta ? -1 : a.delta === b.delta ? 0 : 1);
  }
}
