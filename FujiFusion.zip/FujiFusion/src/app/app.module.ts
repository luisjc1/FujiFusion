import {BrowserModule} from '@angular/platform-browser';
import {ErrorHandler, NgModule} from '@angular/core';
import {IonicApp, IonicErrorHandler, IonicModule} from 'ionic-angular';

import {MyApp} from './app.component';
import {InvestmentsPage} from "../pages/investments/investments";
import {InvestmentPage} from "../pages/investment/investment";

import {StatusBar} from '@ionic-native/status-bar';
import {SplashScreen} from '@ionic-native/splash-screen';
import {ExplorePage} from "../pages/explore/explore";
import {HomePage} from "../pages/home/home";
import {SettingsPage} from "../pages/settings/settings";
import {LogoutPage} from "../pages/logout/logout";

import { AngularFireModule } from 'angularfire2';
import { AngularFireDatabaseModule } from 'angularfire2/database'

// AngularFire2 Settings (from Firebase)
var config = {
  apiKey: "AIzaSyCN2zl5qMT0C1O3voRxMqSF_htWd96vyHg",
  authDomain: "fujifusion.firebaseapp.com",
  databaseURL: "https://fujifusion.firebaseio.com",
  projectId: "fujifusion",
  storageBucket: "fujifusion.appspot.com",
  messagingSenderId: "257868717070"
};

@NgModule({
  declarations: [
    MyApp,
    InvestmentsPage,
    ExplorePage,
    InvestmentPage,
    HomePage,
    SettingsPage,
    LogoutPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    AngularFireDatabaseModule,
    AngularFireModule.initializeApp(config)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    InvestmentsPage,
    ExplorePage,
    InvestmentPage,
    HomePage,
    SettingsPage,
    LogoutPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {
}
