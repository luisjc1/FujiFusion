import {Component, ViewChild} from '@angular/core';
import {Nav, Platform} from 'ionic-angular';
import {StatusBar} from '@ionic-native/status-bar';
import {SplashScreen} from '@ionic-native/splash-screen';

import {InvestmentsPage} from '../pages/investments/investments';
import {ExplorePage} from "../pages/explore/explore";
import {HomePage} from "../pages/home/home";
import {SettingsPage} from "../pages/settings/settings";
import {LogoutPage} from "../pages/logout/logout";
import {InfoPage} from "../pages/info/info";

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  rootPage: any = HomePage;

  pages: Array<{ title: string, icon: string, component: any }>;

  constructor(public platform: Platform, public statusBar: StatusBar, public splashScreen: SplashScreen) {
    this.initializeApp();

    this.pages = [
      {title: 'Home', icon: 'home',component: HomePage},
      {title: 'Investments', icon: 'cash',component: InvestmentsPage},
      {title: 'Explore', icon: 'compass',component: ExplorePage},
      {title: 'Settings', icon: 'settings',component: SettingsPage},
      {title: 'Logout', icon: 'log-out', component: LogoutPage}
    ];

  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }

  openPage(page) {
    this.nav.setRoot(page.component);
  }
}
