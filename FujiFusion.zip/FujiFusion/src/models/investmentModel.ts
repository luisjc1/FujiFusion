export class InvestmentModel {
  public companyName: string;
  public ticker: string;
  public vendorCreditRating: string;
  public RBCCreditRating: string;
  public delta: number;
  public value: number;
}
